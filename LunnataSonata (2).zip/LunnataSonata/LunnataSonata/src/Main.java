public class Main {
    public static void main(String[] args) throws Exception {

        Player player = new Player();
        Builder.build(player);
        player.play();
    }
}
