public class Note {
    private int pitch;
    private int volume;
   private long timestamp;
   private long starting;

   public Note(int pitch, int volume, long starting, long timestamp) {
        this.pitch = pitch;
        this.volume = volume;
        this.timestamp = timestamp;
        this.starting = starting;
   }

    public int getPitch() {
        return pitch;
    }

    public void setPitch(int pitch) {
        this.pitch = pitch;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    public long getStarting() {
        return starting;
    }
    public void setStarting(long starting) {}
}
