import javax.sound.midi.*;

public class Player {
    private Sequencer sequencer;
    private Sequence sequence;
    private Track track;

    public Player() throws Exception {
        sequencer = MidiSystem.getSequencer();
        sequencer.open();

        sequence = new Sequence(Sequence.PPQ, 24);
        track = sequence.createTrack();
    }

    public void addNote(Note note) throws Exception {

        ShortMessage on = new ShortMessage();
        on.setMessage(ShortMessage.NOTE_ON, 0,
                note.getPitch(), note.getVolume());

        track.add(new MidiEvent(on, note.getStarting()));

        ShortMessage off = new ShortMessage();
        off.setMessage(ShortMessage.NOTE_OFF, 0,
                note.getPitch(), 0);

        track.add(new MidiEvent(off,
                note.getStarting() + note.getTimestamp()));
    }


    public void play() throws Exception {


            sequencer.setSequence(sequence);
        sequencer.setTempoInBPM(52);
            sequencer.start();
            while (sequencer.isRunning()) {
                Thread.sleep(100);
            }
            sequencer.stop();
        sequencer.close();
    }



}
