public class Builder {

    public static void build(Player player) throws Exception {

        long tick = 0;

        for (int bar = 0; bar < 8; bar++) {

            player.addNote(new Note(49, 70, tick, 96));
            for (int i = 0; i < 4; i++) {
                player.addNote(new Note(56, 80, tick, 8));
                player.addNote(new Note(61, 80, tick + 8, 8));
                player.addNote(new Note(64, 80, tick + 16, 8));

                tick += 24;
            }
        }
    }
}

